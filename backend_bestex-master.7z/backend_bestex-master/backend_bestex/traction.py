from django.conf import settings
import pyodbc as ctds


def db_conn():
    connection = ctds.connect(
        host=settings.TF_MSSQL_HOST,
        user=settings.TF_MSSQL_USER,
        password=settings.TF_MSSQL_PASSWORD,
        database=settings.TF_MSSQL_DB,
    )
    # connection = ctds.connect(
    #     server=settings.TF_MSSQL_HOST,
    #     port=settings.TF_MSSQL_PORT,
    #     user=settings.TF_MSSQL_USER,
    #     password=settings.TF_MSSQL_PASSWORD,
    #     database=settings.TF_MSSQL_DB,
    #     timeout=5,
    # )
    return connection


def db_test():
    connection = db_conn()
    with connection:
        with connection.cursor() as cursor:
            cursor.execute('SELECT @@VERSION AS Version')
            row = cursor.fetchone()

    # Columns can be accessed by index, name, or attribute.
    assert row[0] == row['Version']
    print(row.Version)


def get_client_codes_like(s):
    connection = db_conn()
    with connection:
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT TOP 5 client_code
                FROM AUS.dbo.lei_numbers
                WHERE client_code LIKE :0
                ORDER BY client_code;
            """, (s + '%',))
            rows = cursor.fetchall()
    return [str(row[0]) for row in rows]
