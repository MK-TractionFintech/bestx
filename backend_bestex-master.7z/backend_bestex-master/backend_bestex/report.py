import datetime
import pytz
import logging

from rest_framework.views import APIView
from rest_framework.response import Response

from backend_bestex.traction import db_conn

logger = logging.getLogger(__name__)

UTCTZ = pytz.utc
_FIRST_SECOND = datetime.time(0, 0, 0)


def cases_sql(field, cases, tabs=3):
    return '\n'.join("{} WHEN {} = {} THEN '{}'".format('\t' * tabs, field, x[0], x[1])
                     for x in cases)


def get_current_date_in_tz(tz):
    return datetime.datetime.now(tz).date()


def convert_tz_to_tz(dt, fromtz=UTCTZ, totz=UTCTZ):
    if fromtz == totz:
        return dt
    return fromtz.localize(dt).astimezone(totz)


def map_days_to_time_range(days=None, tz=UTCTZ):
    # convert a # of days to data date range

    if days == 'week':
        days = 7
    elif days == 'month':
        days = 30
    elif days == 'day':
        days = 0
    else:
        days = int(days)

    last_date = get_current_date_in_tz(tz)
    first_date = last_date - datetime.timedelta(days)

    start_time = start_date_as_time(first_date)
    end_time = end_date_as_time(last_date)

    return start_time, end_time


def start_date_as_time(start_date):
    # first second of start day
    return datetime.datetime.combine(start_date, _FIRST_SECOND)


def end_date_as_time(end_date):
    # first second of day after last _FIRST_SECOND
    return datetime.datetime.combine(end_date + datetime.timedelta(days=1), _FIRST_SECOND)


def get_data_time_range(start_time_input=None, end_time_input=None, days_input=None,
                        input_tz=UTCTZ, data_tz=UTCTZ):

    if start_time_input is None and end_time_input is None:
        start_time_input, end_time_input = map_days_to_time_range(days_input or 'day', input_tz)

    if type(start_time_input) == datetime.date:
        start_time_input = start_date_as_time(start_time_input)

    if type(end_time_input) == datetime.date:
        end_time_input = end_date_as_time(end_time_input)

    if input_tz != data_tz:
        if start_time_input is not None:
            start_time_data = convert_tz_to_tz(start_time_input, input_tz, data_tz)
        if end_time_input is not None:
            end_time_data = convert_tz_to_tz(end_time_input, input_tz, data_tz)
    else:
        start_time_data = start_time_input
        end_time_data = end_time_input

    return (start_time_data, end_time_data)


def time_in_range_sql(start_time=None, end_time=None, column_sql='time'):

    if start_time is None and end_time is None:
        return 'TRUE'

    begin = end = ''

    if start_time is not None:
        begin = '{} >= \'{}\''.format(column_sql, start_time.strftime('%Y-%m-%d %H:%M:%S'))
    if end_time is not None:
        end = '{} < \'{}\''.format(column_sql, end_time.strftime('%Y-%m-%d %H:%M:%S'))

    if begin and end:
        return '{} AND {}'.format(begin, end)

    return begin or end


class Report:

    keys = []
    generated_keys = []
    unique_key = None
    columns = []
    data = []

    _base_where_dict = {}
    data_tz = UTCTZ

    def get_filter_values(self, *args, **kwargs):
        print(args, kwargs)
        if self.generated_keys:
            print('getting filter values the hard way', kwargs)

            data = self.generate(*args, **kwargs)
            filter_vals = {}
            keys = self.keys + self.generated_keys
            for row in data:
                for k in keys:
                    if row[k]:
                        filter_vals.setdefault(k, set()).add(row[k])
            filter_vals = {k: sorted(list(v)) for k, v in filter_vals.items()}
            return filter_vals
        else:
            print('getting filter values the easy way', kwargs)

            # group by all keys
            kwargs['group_by'] = kwargs['order_by'] = list(self.keys)

            data = self.generate(*args, **kwargs)
            filter_vals = {}
            for row in data:
                for k in self.keys:
                    if row[k]:
                        filter_vals.setdefault(k, set()).add(row[k])
            filter_vals = {k: sorted(list(v)) for k, v in filter_vals.items()}
            return filter_vals

    def generate(self, where=None, group_by=None, order_by=None, offset=None, num_rows=None,
                 start_time=None, end_time=None, days=None, fmt=None, input_tz=UTCTZ):
        """
        (all parameters are  optional)

        Equals:
        where = {"<column_name>":"<equals_value>"}
        Ex: {"account_id": 5}, {"acc_type": "asset"}

        IN:
        where = {"<column_name>": <iterable of values>}
        Ex: {"account_id": [13,17,19]}

        Other comparison (use double underscore and suffix code):
        available suffixes for comparisons: ['gt', 'lt', 'gte', 'lte']
        where = {"<column_name>__gte": "<gte_value>"}
        Ex: (commissions of 1 or more)
        {"commission_amount__gte": 1.00}

        Null:
        Explicitly pass the string literal "null" for the column to be included in the query
        where = {"<column_name": "null"}

        group_by = list of keys ['key1', 'key2']
        order_by = list of keys ['keyX', 'keyY']
        start_time = datetime
        end_time = datetime
        days = <integer>     only used if no start_time or end_time are provided
        """
        self.fmt = fmt

        if self.unique_key is not None and where is not None and self.unique_key in where:
            self.where_dict = {self.unique_key: where[self.unique_key]}
            # this is just an explicit assignment for clarity
            self.start_time = None
            self.end_time = None
        else:
            # Ignore the filter if the value is 'all'
            self.where_dict = {k: where[k]
                               for k in where
                               if k in self.keys and
                               where[k][0] != 'all'} if where is not None else {}
            self.filter_dict = {k: where[k]
                                for k in where
                                if k in self.generated_keys and
                                where[k][0] != 'all'} if where is not None else {}
            # apply the base_where no matter what
            self.where_dict.update(self.build_base_where())

            self.start_time, self.end_time = get_data_time_range(
                start_time, end_time, days, input_tz, self.data_tz)
            if self.start_time >= self.end_time:

                raise ValueError('start_time must be before end_time')

        self.group_by_keys = [k for k in group_by if k in self.keys] if group_by is not None else []

        # if we are filtering AND grouping, we must also group the query by those filtering columns
        # "actual_group_by_keys" is what the query has to use to get the correct data
        # "group_by_keys" is what the user expects the data returned to be grouped by
        if self.group_by_keys and self.where_dict:
            self.actual_group_by_keys = list(
                set(self.group_by_keys + list(self.where_dict.keys())))
        else:
            self.actual_group_by_keys = self.group_by_keys

        self.order_by = [k for k in order_by if k] if order_by else None
        self.offset = offset
        self.num_rows = num_rows

        self.get_data()
        return self.fmt_data(self.columns, self.data)

    def build_base_where(self):
        # useful for extending a report class by filtering it permanently
        return self._base_where_dict

    def fmt_data(self, columns, data):
        return [dict(zip(columns, row)) for row in data]


class SQLReport(Report):

    # if select statements are not dynamic, or summary data mode isn't supported
    # just assign these attributes the relevant values and you can still use the
    # filtering and ordering functionality
    _with_sql = ''
    _data_select_sql = 'SELECT *'
    _summary_select_sql = ''
    _table = ''

    def get_data(self):
        sql = self.build_sql()
        print("The query is:")
        print(self.params)
        self.run_query(sql, self.params)

    def build_sql(self):
        # builds a generic sql query by calling individual functions for each section of sql
        self.params = []
        sql = """
            {with_sql}
            {select_sql}
            {from_sql}
            {where_sql}
            {group_by_sql}
            {order_by_sql}
            {offset_sql}
        """.format(
            with_sql=self.build_with_sql(),
            select_sql=self.build_select_sql(),
            from_sql=self.build_from_sql(),
            where_sql=self.build_where_sql(),
            group_by_sql=self.build_group_by_sql(),
            order_by_sql=self.build_order_by_sql(),
            offset_sql=self.build_offset_sql(),
        )

        return '\n'.join(s for s in sql.split('\n') if s.strip())

    def run_query(self, sql, params=None):
        params = params or ()
        print(sql)
        print(params)

        connection = db_conn()
        with connection:
            with connection.cursor() as cursor:
                    #cursor.execute(sql, params)
                    cursor.callproc('[dbo].[test_proc]',params)
                    self.data = cursor.fetchall()
                    self.columns = [column.name for column in cursor.description]
        print("query end")

    def build_with_sql(self):
        return self._with_sql

    def build_select_sql(self):
        # columns are completely different if we're grouping by any keys

        if not self.group_by_keys:
            # return list of data items
            return self.data_select_sql()

        else:
                # return a list of groupings using the given group_by_keys
                # add some columns that are useful when navigating the report manually
            return """
                SELECT
                {},
                {} as data_query,
                {} as drill_down_query,
                {} as key_fields,
                {} as key_vals,
                {} as key_name
                {}""".format(
                self.build_key_fields_select(),
                self.build_data_query_column(),  # query params to see the data of this group
                self.build_drill_down_query_column(),  # recommend a key to drill down on next
                self.build_key_fields_column(),  # what keys are we currently grouping by?
                self.build_key_vals_column(),  # what are the key values for this grouping?
                self.build_name_column(),  # display name for this grouping, if diff than vals
                self.summary_select_sql(),  # build the aggregate columns (sum, count, etc)
            )

    def summary_select_sql(self):
        return self._summary_select_sql

    def data_select_sql(self):
        return self._data_select_sql

    def build_from_sql(self):
        return 'FROM ' + self._table

    SUFFIX_MAP = {
        'gte': '>=',
        'gt': '>',
        'lte': '<=',
        'lt': '<',
        'ne': '!=',
    }

    # classmethod
    def map_suffix(cls, suffix):
        return cls.SUFFIX_MAP.get(suffix, '=')

    def build_where_sql(self, params=None):
        """
        Convert where_dict into sql statements
        {"cliend_id": "4"} -> "client_id = %s and params += (4,6,9)"
        {"cliend_id": "4,6,9"} -> "client_id in (%s, %s, %s) and params += (4,6,9)"
        """
        if params is None:
            # if you don't want the params added to the global params list then pass in a list
            params = self.params
        assert isinstance(self.where_dict, dict)

        if not self.where_dict:
            return ''
        print(self.where_dict)
        qs = []
        for k, v in self.where_dict.items():
            if isinstance(v, list) or isinstance(v, tuple):
                if k.endswith('__not'):
                    p = 'not'
                else:
                    p = ''
                ins = v
                qs.append("{} {} in ({}) \n".format(
                    k, p, ', '.join(['%s' for x in range(len(ins))])))
                self.params += ins
            else:
                if str(v).lower() == 'null':
                    qs.append("{} IS NULL".format(k))
                elif '__' in k:
                    k, suffix = k.split('__')
                    qs.append("{} {} %s \n".format(k, self.map_suffix(suffix)))
                else:
                    qs.append("{} = %s \n".format(k))
                self.params.append(v)
        num_params = tuple(':{}'.format(i) for i in range(len(self.params)))
        wheres = ' AND '.join(qs)
        wheres = wheres % num_params

        return 'WHERE ' + wheres

    def build_group_by_sql(self):
        if not self.actual_group_by_keys:
            return ''

        assert isinstance(self.actual_group_by_keys, list)

        ids = ['"{}"'.format(k) for k in self.actual_group_by_keys]
        names = ['"{}"'.format(k.replace('id', 'name'))
                 for k in self.actual_group_by_keys]
        return 'GROUP BY {}'.format(', '.join(set(ids + names)))

    def build_order_by_sql(self):
        if not self.order_by:
            return ''

        assert isinstance(self.order_by, list)
        _order_by = []
        for k in self.order_by:
            if k[0] == '-':
                k = "{} DESC".format(k[1:])
            _order_by.append(k)
        return 'ORDER BY ' + ','.join(_order_by)

    def build_offset_sql(self):
        if self.offset and self.num_rows:
            return """OFFSET {offset} ROWS FETCH NEXT {num_rows} ROWS ONLY
            """.format(offset=self.offset, num_rows=self.num_rows)
        else:
            return ''

    def build_data_query_column(self):

        return "concat('?', {})".format(
            ",'&',".join('\'{}=\',"{}"'.format(k, k) for k in self.actual_group_by_keys))

    def build_drill_down_query_column(self):

        next_keys = [k for k in self.keys if k not in self.group_by_keys]
        if next_keys:
            q = "concat('?', {}, '&group_by={}')".format(
                ",'&',".join('\'{}=\',"{}"'.format(k, k)
                             for k in self.actual_group_by_keys),
                next_keys[0])
        else:
            q = "''"
        return q

    def build_key_fields_select(self):
        return ','.join('"{}"'.format(k) for k in self.group_by_keys)

    def build_key_fields_column(self):

        return "'{}'".format(", ".join(self.group_by_keys))

    def build_key_vals_column(self):

        return "concat({}, '')".format(
            ",',',".join('"{}"'.format(k) for k in self.group_by_keys))

    def build_name_column(self):
        if self.group_by_keys is None:
            return ''

        assert isinstance(self.group_by_keys, list)

        return 'CONCAT({}, \'\')'.format(",', ',".join(
            ['"{}"'.format(k.replace('id', 'name')) for k in self.group_by_keys]))


class ReportView(APIView):
    report_class = None

    def get_report(self, request):
        return self.report_class

    @staticmethod
    def parse_date_or_datetime(str_input):
        try:
            result = datetime.datetime.strptime(str_input, '%Y-%m-%d %H:%M:%S')
        except ValueError:
            try:
                result = datetime.datetime.strptime(str_input, '%Y-%m-%d').date()
            except ValueError:
                result = None
        return result

    def get(self, request, **kwargs):
        """map reserved query param keys to the correct types
        remaining keys added to "where" clause"""

        reserved = ['group_by', 'start_time', 'end_time',
                    'days', 'order_by', 'offset', 'num_rows', 'fmt']
        where = {}
        for k, v in request.query_params.items():
            if k not in reserved:
                if ',' in v:
                    where[k] = v.split(',')
                else:
                    where[k] = v

        start_time = request.query_params.get('start_time', None)
        if start_time is not None:
            start_time = self.parse_date_or_datetime(start_time)

        end_time = request.query_params.get('end_time', None)
        if end_time is not None:
            end_time = self.parse_date_or_datetime(end_time)

        days = request.query_params.get('days', None)

        group_by = request.query_params.get('group_by', '').split(',')
        order_by = request.query_params.get('order_by', '').split(',')

        offset = request.query_params.get('offset', None)
        num_rows = request.query_params.get('num_rows', None)

        report = self.get_report(request)

        kwargs = {
            'group_by': group_by,
            'where': where,
            'start_time': start_time,
            'end_time': end_time,
            'days': days,
            'order_by': order_by,
            'offset': offset,
            'num_rows': num_rows
        }
        if request.query_params.get('get_filter_values'):
            data = report.get_filter_values(**kwargs)
        elif request.query_params.get('chart_data'):
            data = report.get_chart_data(**kwargs)
        else:
            data = report.generate(**kwargs)

        return Response(data)


"""
import pandas

class PandasMixin:

    def fmt_df(self, columns, data):
        df = pandas.DataFrame(data, columns=columns)
        if self.group_by_keys:
            df = df.set_index(self.group_by_keys)
            df = df.drop(columns=['data_query', 'drill_down_query',
                                  'key_fields', 'key_vals', 'key_name'])
            df = df.sort_index()
            if self._summary_numeric_keys:
                keys = self._summary_numeric_keys
                df[keys] = df[keys].apply(pandas.to_numeric)
        return df

    def fmt_data(self, columns, data):
        if self.fmt == 'df':
            return self.fmt_df(columns, data)
        else:
            return super().fmt_data(columns, data)
"""
