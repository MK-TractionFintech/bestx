from django.conf import settings
from django.db.models import Q


from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework import viewsets, serializers, mixins, permissions
from rest_framework import exceptions
from .reports import ExecutionsReport

from ..report import ReportView
from ..users.models import Organization, User, Symbol, SymbolClass, SymbolLog


class TFAPIPermission(IsAuthenticated):

    def has_permission(self, request, view):
        if not super().has_permission(request, view):
            return False
        return request.user.has_org_permission(view.organization, self.permission)


class TFAPIAdminPermission(TFAPIPermission):
    permission = User.TYPE_ADMIN


class TFAPIUserModifyPermission(TFAPIPermission):
    permission = User.TYPE_ADMIN

    def has_object_permission(self, request, view, obj):
        # cannot modify admin users (including self)
        if not request.method not in permissions.SAFE_METHODS:
            if obj.has_org_permission(view.organization, User.TYPE_ADMIN):
                return False


class TFAPIEditorPermission(TFAPIPermission):
    permission = User.TYPE_EDITOR


class TFAPIViewerPermission(TFAPIPermission):
    permission = User.TYPE_VIEWER


class TFAPIView(APIView):

    def initial(self, request, *args, **kwargs):
        default_orgid = 1 if settings.DEBUG else None
        self.orgid = request.GET.get('orgid', default_orgid)
        self.organization = None
        if self.orgid:
            try:
                self.organization = Organization.objects.get(id=self.orgid)
            except Organization.DoesNotExist:
                raise exceptions.NotFound('Organization does not exist')
        super().initial(request, *args, **kwargs)


class TFReportView(TFAPIView, ReportView):
    # set default permission
    permission = User.TYPE_VIEWER

    # all reports require an organization
    def get_report(self, request):
        report = self.report_class(organization=self.organization)
        return report


class ExecutionsReportView(TFReportView):
    permission_classes = (TFAPIViewerPermission,)
    report_class = ExecutionsReport


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['email', 'name', 'type', 'is_active']


class UserViewSet(TFAPIView, viewsets.ModelViewSet):
    permission_classes = (TFAPIUserModifyPermission,)
    queryset = User.objects.none()
    serializer_class = UserSerializer

    def get_queryset(self):
        return User.objects.filter(organization=self.organization)

    def update(self, request, *args, **kwargs):
        instance = self.get_object()
        if self.action == 'update':
            if instance.has_org_permission(self.organization, User.TYPE_ADMIN):
                raise exceptions.PermissionDenied("Can't modify admin users")
        return super().update(request, *args,)


class SymbolSerializer(serializers.ModelSerializer):
    symbol_class = serializers.CharField(source='symbol_class.clas', read_only=True)

    class Meta:
        model = Symbol
        fields = [
            'id',
            'symbol_class',
            'symbol',
            'low_max',
            'med_max',
            'use', ]
        read_only_fields = [
            'id',
            'symbol_class',
            'symbol',
        ]

    def validate(self, data):
        if data['low_max'] > data['med_max']:
            raise serializers.ValidationError("Ranges cannot overlap.")
        return data


class SymbolViewSet(TFAPIView, viewsets.GenericViewSet,
                    mixins.ListModelMixin,
                    mixins.UpdateModelMixin,
                    mixins.RetrieveModelMixin):

    permission_classes = (TFAPIEditorPermission,)
    queryset = Symbol.objects.none()
    serializer_class = SymbolSerializer

    def get_queryset(self):
        return Symbol.objects.filter(symbol_class__organization=self.organization).select_related('symbol_class')  # noqa

    def perform_update(self, serializer):
        instance = self.get_object()
        s = ''
        vd = serializer.validated_data
        if 'low_max' in vd and instance.low_max != vd['low_max']:
            # they changed low_max
            s += 'low_max {} -> {}'.format(instance.low_max, vd['low_max'])
        if 'med_max' in vd and instance.med_max != vd['med_max']:
            # they changed med_max
            s += ' med_max {} -> {}'.format(instance.med_max, vd['med_max'])

        if 'use' in vd and instance.use != vd['use']:
            # they changed use
            s += ' use {} -> {}'.format(instance.use, vd['use'])

        use = vd.get('use')
        if use is None and s:
            # didn't send a value for 'use' but changed something, so we set use to True
            instance = serializer.save(use=True)
        else:
            # default behavior
            instance = serializer.save()

        if s:
            # they changed something
            SymbolLog.objects.create(
                user=self.request.user,
                symbol_class=None,
                symbol=instance,
                message=s)


class SymbolClassSerializer(serializers.ModelSerializer):

    class Meta:
        model = SymbolClass
        fields = [
            'id',
            'clas',
            'low_max',
            'med_max']
        read_only_fields = [
            'id',
            'clas',
        ]

    def validate(self, data):
        if data['low_max'] > data['med_max']:
            raise serializers.ValidationError("Ranges cannot overlap.")
        return data


class SymbolClassViewSet(TFAPIView, viewsets.GenericViewSet,
                         mixins.ListModelMixin,
                         mixins.UpdateModelMixin,
                         mixins.RetrieveModelMixin):

    permission_classes = (TFAPIEditorPermission,)
    queryset = SymbolClass.objects.none()
    serializer_class = SymbolClassSerializer

    def get_queryset(self):
        return SymbolClass.objects.filter(organization=self.organization)

    def perform_update(self, serializer):
        instance = self.get_object()
        s = ''
        if instance.low_max != serializer.validated_data['low_max']:
            # they changed low_max
            s += 'low_max {} -> {}'.format(instance.low_max, serializer.validated_data['low_max'])
        if instance.med_max != serializer.validated_data['med_max']:
            # they changed med_max
            s += ' med_max {} -> {}'.format(instance.med_max, serializer.validated_data['med_max'])

        super().perform_update(serializer)

        if s:
            # they changed something
            SymbolLog.objects.create(
                user=self.request.user,
                symbol_class=instance,
                symbol=None,
                message=s)


class SymbolLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = SymbolLog
        fields = ['modified', 'user', 'symbol', 'symbol_class', 'message']
        read_only_fields = fields


class SymbolLogViewSet(TFAPIView, viewsets.GenericViewSet,
                       mixins.ListModelMixin,
                       mixins.RetrieveModelMixin):

    permission_classes = (TFAPIEditorPermission,)
    queryset = SymbolLog.objects.none()
    serializer_class = SymbolLogSerializer

    def get_queryset(self):
        return SymbolLog.objects.filter(
            Q(symbol__symbol_class__organization=self.organization) |
            Q(symbol_class__organization=self.organization))
