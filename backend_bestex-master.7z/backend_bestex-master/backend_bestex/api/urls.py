from django.urls import path
from . import views
from rest_framework import routers


urlpatterns = [
    path('executions/', views.ExecutionsReportView.as_view())
]

router = routers.DefaultRouter()
router.register(r'symbols', views.SymbolViewSet)
router.register(r'symbol_classes', views.SymbolClassViewSet)
router.register(r'symbol_logs', views.SymbolLogViewSet)
router.register(r'users', views.UserViewSet)


urlpatterns += router.urls
