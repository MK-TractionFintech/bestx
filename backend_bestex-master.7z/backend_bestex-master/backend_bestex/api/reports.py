from collections import defaultdict, Counter

from django.conf import settings

from ..report import SQLReport, time_in_range_sql
from ..users.models import Symbol, SymbolClass


class TFReport(SQLReport):
    def __init__(self, organization, *args, **kwargs):
        self.organization = organization
        self.client_code = organization.client_code
        super().__init__(*args, **kwargs)


class ExecutionsReport(TFReport):
    unique_key = 'deal'
    keys = ['login', 'class', 'symbol', 'type']
    generated_keys = ['favor', 'range', 'deviation']
    chart_data = False

    def build_with_sql(self):
        return """
            WITH executions as (
                SELECT
                    deal,
                    login,
                    class,
                    symbol,
                    CASE
                    WHEN ([type] = 'buy' AND [action] = 'new')
                        OR ([type] = 'sell' AND [action] = 'exit') THEN 'buy'
                        ELSE 'sell'
                    END AS type,
                    type as orig_type,
                    volume,
                    tran_time,
                    low_ask,
                    high_ask,
                    open_ask,
                    close_ask,
                    low_bid,
                    high_bid,
                    open_bid,
                    close_bid,
                    client_price,
                    CASE
                        WHEN abs(DistanceFromBest) < abs(DistanceFromWorst) THEN abs(DistanceFromBest)
                        WHEN abs(DistanceFromBest) > abs(DistanceFromWorst) THEN abs(DistanceFromWorst)
                        ELSE abs(DistanceFromBest)
                    END AS deviation_amount,
                    CASE
                        WHEN abs(DistanceFromBest) < abs(DistanceFromWorst) THEN 'client'
                        WHEN abs(DistanceFromBest) > abs(DistanceFromWorst) THEN 'broker'
                        ELSE null
                    END AS favor
                FROM {}
                WHERE client_code ='{}')
        """.format(settings.TF_EXECUTION_TABLE,
                   self.client_code)

    def get_chart_data(self, *args, **kwargs):
        self.chart_data = True
        return self.generate(*args, **kwargs)

    _table = 'executions'

    _data_select_sql = """SELECT *"""

    def build_where_sql(self):
        sql = super().build_where_sql()
        if sql:
            sql += ' AND '
        else:
            sql += ' WHERE '
        sql += time_in_range_sql(self.start_time, self.end_time, 'tran_time')
        return sql

    def fmt_data(self, columns, data):
        execs = []
        counts = defaultdict(int)
        symbols = Counter()
        logins = Counter()
        if self.group_by_keys:
            return super().fmt_data(columns, data)
        settings = {}
        for s in Symbol.objects.filter(symbol_class__organization=self.organization).select_related('symbol_class'):  # noqa
            if s.use:
                settings[s.symbol] = (s.low_max, s.med_max, s.symbol)
            else:
                settings[s.symbol] = (s.symbol_class.low_max,
                                      s.symbol_class.med_max, s.symbol_class.clas)

        for row in data:
            dev = None
            if row['symbol'] in settings:
                setting = settings[row['symbol']]
            else:
                # new symbol
                symbol_class, created = SymbolClass.objects.get_or_create(
                    organization=self.organization,
                    clas=row['class'],
                    defaults={
                        'low_max': 0,
                        'med_max': 0,
                    }
                )
                if created:
                    print('created {}'.format(symbol_class))

                s = Symbol.objects.create(
                    symbol_class=symbol_class,
                    symbol=row['symbol'],
                    low_max=symbol_class.low_max,
                    med_max=symbol_class.med_max,
                    use=False,
                )
                print('created {}'.format(s.symbol))
                setting = settings[row['symbol']] = (s.symbol_class.low_max,
                                                     s.symbol_class.med_max,
                                                     s.symbol_class.clas)

            # calculate favor and range
            favor = row['favor']
            if row['type'] == 'buy':
                if row['client_price'] < row['low_ask']:
                    rang = 'out'
                    if favor is None:
                        favor = 'client'
                elif row['client_price'] > row['high_ask']:
                    rang = 'out'
                    if favor is None:
                        favor = 'broker'
                else:
                    rang = 'in'

                ohlc = {
                    'low': float(row['low_ask']),
                    'high': float(row['high_ask']),
                    'open': float(row['open_ask']),
                    'close': float(row['close_ask']),
                }
            elif row['type'] == 'sell':
                if row['client_price'] > row['high_bid']:
                    rang = 'out'
                    if favor is None:
                        favor = 'client'
                elif row['client_price'] < row['low_bid']:
                    rang = 'out'
                    if favor is None:
                        favor = 'broker'
                else:
                    rang = 'in'

                ohlc = {
                    'low': float(row['low_bid']),
                    'high': float(row['high_bid']),
                    'open': float(row['open_bid']),
                    'close': float(row['close_bid']),
                }

            # set deviation level
            if rang == 'in':
                dev = favor = None
            else:
                if row['deviation_amount'] == 0:
                    dev = None
                if row['deviation_amount'] > 0:
                    dev = 'low'
                    if row['deviation_amount'] > setting[0]:
                        dev = 'med'
                    if row['deviation_amount'] > setting[1]:
                        dev = 'high'

            e = {
                'deal': row['deal'],
                'login': row['login'],
                'symbol': row['symbol'],
                'class': row['class'],
                'type': row['type'],
                'orig_type': row['orig_type'],
                'volume': '{:0.2f}'.format(row['volume'] if row['volume'] else 0),
                'datetime': row['tran_time'].strftime('%Y-%m-%d %H:%M:%S.%f'),
                'clientPrice': float(row['client_price']),
                'deviation_amount': float(row['deviation_amount']),
                'favor': favor,
                'range': rang,
                'deviation': dev,
                'setting': setting[2],
            }
            e.update(ohlc)

            count = False
            if self.filter_dict:
                if all([e[k] == self.filter_dict[k] for k in self.filter_dict.keys()]):
                    count = True
            else:
                count = True

            if count:
                execs.append(e)
                symbols[e['symbol']] += 1
                logins[e['login']] += 1
                counts['n'] += 1
                if e['range'] == 'in':
                    counts['inn'] += 1
                else:
                    counts['out'] += 1

                if e['favor'] == 'broker':
                    counts['f_broker'] += 1
                elif e['favor'] == 'client':
                    counts['f_client'] += 1
                else:
                    counts['f_none'] += 1

                if e['deviation'] is None:
                    counts['no_dev'] += 1
                if e['deviation'] == 'low':
                    counts['low'] += 1
                elif e['deviation'] == 'med':
                    counts['med'] += 1
                elif e['deviation'] == 'high':
                    counts['high'] += 1

        if self.chart_data:
            return {
                'deviation': {
                    'high': counts['high'],
                    'med': counts['med'],
                    'low': counts['low'],
                    None: counts['no_dev']
                },
                'range': {'in': counts['inn'], 'out': counts['out']},
                'favor': {'broker': counts['f_broker'],
                          'client': counts['f_client'],
                          None: counts['f_none']},
                'total': counts['n'],
                'symbols': symbols.most_common(15),
                'logins': logins.most_common(15),
            }
        return execs
