from django.contrib.auth.models import AbstractUser
from django.db import models
from django.db.models import CharField
from django.urls import reverse
from django.utils.translation import ugettext_lazy as _

from backend_bestex import traction


class User(AbstractUser):
    TYPE_ADMIN = 'admin'
    TYPE_EDITOR = 'editor'
    TYPE_VIEWER = 'viewer'
    TYPES = [TYPE_ADMIN, TYPE_EDITOR, TYPE_VIEWER]
    TYPE_CHOICES = [(t, t.title()) for t in TYPES]

    name = CharField(_("Name of User"), blank=True, max_length=255)
    organization = models.ForeignKey(
        'Organization', null=True, blank=True, on_delete=models.CASCADE)
    REQUIRED_FIELDS = ['username']
    USERNAME_FIELD = 'email'

    type = models.CharField(choices=TYPE_CHOICES, max_length=10, default=TYPE_VIEWER)

    def get_absolute_url(self):
        return reverse("users:detail", kwargs={"username": self.username})

    def has_org_permission(self, organization, permission):
        if self.is_superuser or self.is_staff:
            return True
        else:
            # client user
            if self.organization != organization:
                return False
            if not self.organization.active:
                return False
            # permission types
            if permission == User.TYPE_VIEWER:
                return self.type in [User.TYPE_ADMIN, User.TYPE_EDITOR, User.TYPE_VIEWER]
            elif permission == User.TYPE_EDITOR:
                return self.type in [User.TYPE_ADMIN, User.TYPE_EDITOR]
            elif permission == User.TYPE_ADMIN:
                return self.type == User.TYPE_ADMIN
            else:
                return False

    def save(self, *args, **kwargs):
        if self.username != self.email:
            self.email = self.username
        super().save(*args, **kwargs)


class Organization(models.Model):
    name = models.CharField(max_length=255)
    client_code = models.CharField(max_length=10, unique=True, blank=True)
    active = models.BooleanField(default=True)

    class Meta:
        ordering = ['client_code']

    def __str__(self):
        return '{} - {}'.format(self.client_code, self.name)


class SymbolClass(models.Model):
    class Meta:
        verbose_name_plural = 'Symbol Classes'

    organization = models.ForeignKey(Organization, on_delete=models.CASCADE, related_name='symbol_classes')  # noqa
    clas = models.CharField(max_length=20)
    low_max = models.DecimalField(max_digits=18, decimal_places=6)
    med_max = models.DecimalField(max_digits=18, decimal_places=6)

    def __str__(self):
        return '{} - {}'.format(self.organization.client_code, self.clas)


class Symbol(models.Model):
    symbol_class = models.ForeignKey(SymbolClass, on_delete=models.CASCADE, related_name='symbol_classes')  # noqa
    symbol = models.CharField(max_length=200)
    low_max = models.DecimalField(max_digits=18, decimal_places=6)
    med_max = models.DecimalField(max_digits=18, decimal_places=6)
    use = models.BooleanField(default=False)

    def __str__(self):
        return self.symbol

    @staticmethod
    def sync(organizations=None):
        if organizations is None:
            organizations = Organization.objects.all()
        orgs = {org.client_code: org for org in organizations}
        symbol_classes = {(sc.organization.client_code, sc.clas): sc
                          for sc in SymbolClass.objects.all()}

        loc_symbols = set(list(Symbol.objects.all().values_list(
            'symbol_class__organization__client_code', 'symbol_class__clas', 'symbol')))
        print(str(tuple(orgs.keys())).replace(',)', ')'))

        connection = traction.db_conn()
        with connection:
            with connection.cursor() as cursor:
                sql = """
                    SELECT client_code, class, symbol
                    FROM dbo.Symbols
                    WHERE client_code in """ + str(tuple(orgs.keys())).replace(',)', ')')
                print(sql)
                cursor.execute(sql)
                rows = cursor.fetchall()
        print("Herer")
        rem_symbols = set([(row[0], row[1], row[2]) for row in rows])
        new_symbols = rem_symbols - loc_symbols
        print(len(new_symbols), 'new symbols')
        created = 0
        for new_symbol in list(new_symbols):
            print('creating', new_symbol)
            client_code, symbol_class, symbol = new_symbol
            org = orgs[client_code]

            if (client_code, symbol_class) not in symbol_classes:
                sc = SymbolClass.objects.create(
                    organization=org,
                    clas=symbol_class,
                    low_max=0,
                    med_max=0)
                symbol_classes[(client_code, sc.clas)] = sc
            else:
                sc = symbol_classes[(client_code, symbol_class)]

            Symbol.objects.create(
                symbol_class=sc,
                symbol=symbol,
                low_max=sc.low_max,
                med_max=sc.med_max)
            created += 1
        return created


class SymbolLog(models.Model):
    class Meta:
        verbose_name_plural = 'Symbol Logs'

    symbol_class = models.ForeignKey(SymbolClass, on_delete=models.CASCADE, null=True, blank=True)
    symbol = models.ForeignKey(Symbol, on_delete=models.CASCADE, null=True, blank=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    modified = models.DateTimeField(auto_now_add=True)
    message = models.CharField(max_length=255)
