from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _


class UsersConfig(AppConfig):
    name = "backend_bestex.users"
    verbose_name = _("Traction")

    def ready(self):
        try:
            import backend_bestex.users.signals  # noqa F401
        except ImportError:
            pass
