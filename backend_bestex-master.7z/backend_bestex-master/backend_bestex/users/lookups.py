from ajax_select import register, LookupChannel
from .. import traction


@register('clientcodes')
class ClientCodeLookup(LookupChannel):

    def get_query(self, q, request):
        return traction.get_client_codes_like(q)
