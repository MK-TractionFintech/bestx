from rest_framework import serializers
from djoser import serializers as djoser_serializers


class UserSerializer(djoser_serializers.UserSerializer):
    orgid = serializers.IntegerField(source='organization.id', read_only=True)
    organization_name = serializers.CharField(source='organization.name', read_only=True)
    organization_client_code = serializers.CharField(
        source='organization.client_code', read_only=True)

    class Meta(djoser_serializers.UserSerializer.Meta):
        fields = tuple(djoser_serializers.UserSerializer.Meta.fields) + (
            'orgid',
            'type',
            'organization_name',
            'organization_client_code',
        )
        read_only_fields = fields
