from django.contrib import admin, messages
from django.contrib.auth import admin as auth_admin
from django.contrib.auth import get_user_model
from django.forms import ModelForm

from allauth.account.models import EmailAddress
from rest_framework.authtoken.models import Token
from django_celery_beat.models import (
    ClockedSchedule, CrontabSchedule, IntervalSchedule, PeriodicTask, SolarSchedule)
from django.contrib.sites.models import Site
from allauth.socialaccount.models import SocialAccount, SocialApp, SocialToken
from django.contrib.auth.models import Group


from ajax_select.fields import AutoCompleteField


from backend_bestex.users.forms import UserChangeForm, UserCreationForm
from backend_bestex.users.models import Organization, SymbolClass, Symbol, SymbolLog

User = get_user_model()

admin.site.unregister(EmailAddress)
admin.site.unregister(Token)
admin.site.unregister(ClockedSchedule)
admin.site.unregister(CrontabSchedule)
admin.site.unregister(IntervalSchedule)
admin.site.unregister(PeriodicTask)
admin.site.unregister(SolarSchedule)
admin.site.unregister(Site)
admin.site.unregister(SocialAccount)
admin.site.unregister(SocialApp)
admin.site.unregister(SocialToken)
admin.site.unregister(Group)

admin.site.site_header = "Traction Admin"
admin.site.site_title = "Traction Admin"
admin.site.index_title = ""


@admin.register(User)
class UserAdmin(auth_admin.UserAdmin):

    form = UserChangeForm
    add_form = UserCreationForm
    fieldsets = (("User", {"fields": ("name", "organization", "type")}),) + \
        auth_admin.UserAdmin.fieldsets
    list_display = ["username", "name", "is_superuser"]
    search_fields = ["name"]


class OrganizationForm(ModelForm):

    class Meta:
        model = Organization
        fields = ['name', 'client_code']

    client_code = AutoCompleteField('clientcodes')


def sync_symbols(modeladmin, request, queryset):
    try:
        created = Symbol.sync(queryset)
        modeladmin.message_user(request, 'Created {} symbols'.format(created), level=messages.INFO)

    except Exception as e:
        modeladmin.message_user(request, str(e), level=messages.ERROR)


sync_symbols.short_description = 'Sync Symbols for Selected Organizations'


@admin.register(Organization)
class OrganizationAdmin(admin.ModelAdmin):
    actions = [sync_symbols]
    form = OrganizationForm


@admin.register(Symbol)
class SymbolAdmin(admin.ModelAdmin):
    list_display = ['symbol_class', 'symbol', 'low_max', 'med_max', 'use']
    list_filter = ['use', 'symbol_class']
    search_fields = ['symbol', 'symbol_class']


@admin.register(SymbolClass)
class SymbolClassAdmin(admin.ModelAdmin):
    list_display = ['organization', 'clas', 'low_max', 'med_max']
    list_filter = ['organization']


@admin.register(SymbolLog)
class SymbolLogAdmin(admin.ModelAdmin):
    list_display = ['user', 'symbol', 'symbol_class', 'message']
